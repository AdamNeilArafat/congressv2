const FEC_API_KEY = process.env.FEC_API_KEY
  || process.env.fec_api_key
  || "ixhYcu7UzCbPoee2x5pKN1oz9UF3W8V1giNcU1pc"; // hard-coded fallback (public if pushed!)
